const request = require('supertest');
const app = require('../app');
const mongoose = require('mongoose');
const Secret = require('../models/secret');

describe('Secret Endpoints', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true });
  });

  afterAll(async () => {
    await mongoose.connection.close();
  });

  it('should create a new secret', async () => {
    const res = await request(app)
      .post('/secret')
      .send({ message: 'Test secret' });
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('link');
  });

  it('should retrieve and delete the secret', async () => {
    const secret = new Secret({ message: 'Test secret' });
    await secret.save();
    const res = await request(app)
      .get(`/secret/${secret._id}`);
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('message', 'Test secret');
    const secondRes = await request(app)
      .get(`/secret/${secret._id}`);
    expect(secondRes.statusCode).toEqual(404);
  });
});
